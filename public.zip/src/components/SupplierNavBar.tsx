
function SupplierNavBar() {
  return (
    <div>
      
    </div>
  )
}

export default SupplierNavBar
