
const CustomerNavBar = () => {
  return (
    <div>
      
    </div>
  )
}

export default CustomerNavBar
