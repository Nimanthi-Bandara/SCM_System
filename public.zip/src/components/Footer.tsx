function Footer() {
  return (
    <div className="footer">
      <p></p>
    </div>
  )
}

export default Footer
