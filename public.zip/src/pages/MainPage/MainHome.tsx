// import Wallpaper from '../../assets/wallpaper.jpg';

const MainHome = () => {
  return (
    <div className='HomePage'>
      home
      {/* <div className='img-container'>
        <img className='wallpaper' src={Wallpaper}/>
      </div>
      <div className='overlay'>
        <p>Welcome to Stylo</p>
        <h1>From threads to trends,We Weave The future of supply chains</h1>
      </div> */}
    </div>
  )
}

export default MainHome

