

const MainProducts = () => {
  return (
    <div>
      products
    </div>
  )
}

export default MainProducts

