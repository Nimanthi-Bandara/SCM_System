
const MainAbout = () => {
  return (
    <div>
      jhgmjy
    </div>
  )
}

export default MainAbout
